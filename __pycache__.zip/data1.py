import pandas as pd
import random
import string
import numpy as np






def random_string(length=10):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def random_email():
    return f"{random_string(5)}@{random_string(5)}.com"

def random_phone_number():
    return f"+1-{random.randint(100, 999)}-{random.randint(100, 999)}-{random.randint(1000, 9999)}"

def random_address():
    return f"{random.randint(100, 9999)} {random_string(random.randint(5, 10))} St."
def random_id():
    if random.choice([True, False]): 
        return random.randint(1000, 9999)  
    else:
        return random_string(random.randint(5, 10))  


def introduce_bad_data():
    bad_data = random.choice([None, "Invalid Data", random.randint(10000, 99999), "random_string()"])
    return bad_data

def generate_random_dataframe(num_rows=10):
    data = []
    
    for _ in range(num_rows):
        row = {
            "id": random_id(),  
            "name": random_string(5), 
            "last_name": random_string(7),  
            "email": random_email(),  
            "address": random_address(), 
            "phone_number": random_phone_number(), 
            "city": random_string(6),  
            "state": random_string(4),  
            "zip_code": random.randint(10000, 99999),  
            "company": random_string(8), 
        }
        
        if random.choice([True, False]):
            bad_column = random.choice(list(row.keys()))
            row[bad_column] = introduce_bad_data()

        data.append(row)
    df = pd.DataFrame(data)
    return df

