from functions import validate_data as vd
from functions import validate_data1 as vd1
import data1
import psycopg2
df=data1.generate_random_dataframe()


print("connected to docker postgres!")
conn=psycopg2.connect(
    dbname="vaishnavi",
    user="postgres",
    password="123456",
    host="localhost",
    port="5432"
)
conn.autocommit=True

cursor=conn.cursor()
print("connected to docker postgres!")

for _, row in df.iterrows():
    if vd(row):
            insert=f"insert into table5(id,name,last_name,email,phone_number) values {(row['id'],row['name'],row['last_name'],row['email'],row['phone_number'])};" 
            cursor.execute(insert)
            


for _, row in df.iterrows(): 
        if vd1(row):   
            insert=f"insert into table2(id,city,state,zip_code,company) values {(row['id'],row['city'],row['state'],row['zip_code'],row['company'])};" 
            print(insert)
            cursor.execute(insert)