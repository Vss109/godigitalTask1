
def validate_data(row):
    if type(row['id'])==int and row['email'].find("@") !=-1 and row['email'].find(".com")!=-1 and row['phone_number'] :
       return True
    else :
        return False
    return True


def validate_data1(row):
    if type(row['id'])==str and type(row["id"])!=None and type(row['id'])!= int and type(row['city'])==str and isinstance(row['zip_code'],int) and type(row['state'])==str and type(row['company'])==str :
       return True
    else:
        return False
    return True


